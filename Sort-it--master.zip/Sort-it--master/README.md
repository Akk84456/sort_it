# Sort-it!
to visualize bubble, insertion and heap sorting algorithms
# Screenshots
![](Sortit_image1.jpeg)
![](Sortit_image2.jpeg)
![](Sortit_image3.jpeg)
